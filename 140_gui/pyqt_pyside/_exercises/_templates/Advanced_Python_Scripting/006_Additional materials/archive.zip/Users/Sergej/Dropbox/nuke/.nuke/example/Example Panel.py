def Axis_My():  
	n=nuke.createNode("Axis")

	Noise = nuke.PyScript_Knob("Noise","Noise")
	n.addKnob(Noise)
	n['Noise'].setValue('n=nuke.selectedNode()\nn["translate"].setExpression("curve+fBm(frame*xfrequency,10.5,11.5,xoctaves,2,.5)*xamplitude",0)\nn["translate"].setExpression("curve+fBm(frame*yfrequency,10.5,11.5,yoctaves,2,.5)*yamplitude",1)\nn["translate"].setExpression("curve+fBm(frame*zfrequency,10.5,11.5,zoctaves,2,.5)*zamplitude",2)')    

	xtext = nuke.Text_Knob("X_Noise")
	n.addKnob(xtext)
	xfrequency = nuke.Double_Knob("xfrequency","frequency")
	n.addKnob(xfrequency)
	xamplitude = nuke.Double_Knob("xamplitude","amplitude")
	n.addKnob(xamplitude)
	xoctaves = nuke.Double_Knob("xoctaves","octaves")
	n.addKnob(xoctaves)

	ytext = nuke.Text_Knob("Y_Noise")
	n.addKnob(ytext)
	yfrequency = nuke.Double_Knob("yfrequency","frequency")
	n.addKnob(yfrequency)
	yamplitude = nuke.Double_Knob("yamplitude","amplitude")
	n.addKnob(yamplitude)
	yoctaves = nuke.Double_Knob("yoctaves","octaves")
	n.addKnob(yoctaves)

	ztext = nuke.Text_Knob("Z_Noise")
	n.addKnob(ztext)
	zfrequency = nuke.Double_Knob("zfrequency","frequency")
	n.addKnob(zfrequency)
	zamplitude = nuke.Double_Knob("zamplitude","amplitude")
	n.addKnob(zamplitude)
	zoctaves = nuke.Double_Knob("zoctaves","octaves")
	n.addKnob(zoctaves)
	
	
def camSet():
	#may need to un comment next line.
	#import nuke

	#create camera, scene and scanline
	cam = nuke.nodes.Camera()
	scan = nuke.nodes.ScanlineRender()
	scene = nuke.nodes.Scene()

	#connect to scanline
	scan.connectInput(0,cam)
	scan.connectInput(1,scene)
	#connect camera to scene
	scene.connectInput(0, cam)

	#get position
	scanX = scan.xpos()
	scanY = scan.ypos()

	#position scene
	scene['xpos'].setValue(scanX)
	scene['ypos'].setValue(scanY-100)

	#position camera
	cam['xpos'].setValue(scanX-100)
	cam['ypos'].setValue(scanY-100)
	
###################################################
projCam['label'].setValue('(frame [value projFrame])')
button=nuke.PyScript_Knob('currFrame', 'Current Frame','node=nuke.thisNode()\nnode["projFrame"].setValue(nuke.frame())') 
projCam.addKnob(button)
##################################################
if (node.Class() == 'Camera2') or (node.Class() == 'Camera'):
        
	projCam=nuke.createNode('Camera2')       
    projCam.setName('ProjCam')
    projCam['tile_color'].setValue(169550)
    a=nuke.WH_Knob('projFrame','Projection Frame')
               
        
    a.setRange(MIN_MAX[0],MIN_MAX[1])
                
    a.setTooltip('choose the frame you want to project')
                        
    projCam.addKnob(a)
    ### thanks Sirak
    projCam['projFrame'].setValue(MIN_MAX[0])
	
###################################################
def projectionCam():
    f = nuke.frame()
    p = nuke.Panel( "Projection Frame" )
    p.addSingleLineInput( "Frame:", f )
    result = p.show()


##################################################
class captureImagesPanel(nukescripts.PythonPanel):
	'''
	captureImagesPanel
	'''

	def __init__(self):

		initCapture("images")

		nukescripts.PythonPanel.__init__(self, "capture images", "capture images")

		#create elements
		
		'''image tab'''

		self.img_textSave = nuke.Text_Knob( '', 'save/delete', '')
		self.img_name = nuke.String_Knob('name', 'name:')
		self.img_save = nuke.PyScript_Knob('save image', 'save')   
		self.img_delete = nuke.PyScript_Knob('delete image', 'delete')
		self.img_update = nuke.PyScript_Knob('update image', 'update')
		self.img_textCaptured = nuke.Text_Knob( '', 'captured', '')
		self.img_textCaptured.setFlag(nuke.STARTLINE)
		
		#add elements
		self.addKnob(self.img_textSave)
		self.addKnob(self.img_name)
		self.addKnob(self.img_save)
		self.addKnob(self.img_delete) 
		self.addKnob(self.img_update)
		self.addKnob(self.img_textCaptured)

		initCaptureBtn("images", self, capturedImages, capturedImagesBtn)

	def showModalDialog( self ):
		result = nukescripts.PythonPanel.show(self)

	def knobChanged( self, knob ): 

		global capturedImagesBtn
		global capturedImages

		if knob.name() == "save image":

			sel = nuke.selectedNodes()
			if len(sel)==1:
				if sel[0].Class()!="Viewer":

					saveImage(self.img_name.value(), self)

					name=self.img_name.value()
					if("." in name):
						name = name.split(".")[0]

					i=len(capturedImagesBtn)

					self.capBtn = nuke.PyScript_Knob(name, name)

					if i%5==0:
						self.capBtn.setFlag(nuke.STARTLINE)

					self.addKnob(self.capBtn)
					capturedImagesBtn.append(self.capBtn)

				else:
					nuke.message("Node to capture from not allowed")
			elif len(sel)==0:
				nuke.message("Please select a node to capture from")
			elif len(sel)>1:
				nuke.message("Please select only one node")

		if knob.name() == "delete image":
			deleteImageCap(self)

		if knob.name() == "update image":

			for capBtn in capturedImagesBtn:
				self.removeKnob(capBtn)

			capturedImagesBtn = []
			capturedImages = []

			#init all saved images
			for cap in os.listdir(captureImageDir):
				if cap not in dontInclude:
					capturedImages.append(cap)

			initCaptureBtn("images", self, capturedImages, capturedImagesBtn)

		#capture
		else:
			k = "%s.png" % knob.name()
			for capImg in capturedImages:
				if k == capImg:
					loadImage(knob.name())

class captureNodePanel(nukescripts.PythonPanel):
	'''
	captureNodesPanel
	'''

	def __init__(self):


		nukescripts.PythonPanel.__init__(self, "capture nodes", "capture nodes")
		
		initCapture("nodes")

		#create elements
		
		'''image tab'''

		self.n_textSave = nuke.Text_Knob( '', 'save/delete', '')
		self.n_name = nuke.String_Knob('name', 'name:')
		self.n_save = nuke.PyScript_Knob('save nodes', 'save')   
		self.n_delete = nuke.PyScript_Knob('delete nodes', 'delete')
		self.n_update = nuke.PyScript_Knob('update nodes', 'update')
		self.n_textCaptured = nuke.Text_Knob( '', 'captured', '')
		self.n_textCaptured.setFlag(nuke.STARTLINE)
		
		#add elements
		self.addKnob(self.n_textSave)
		self.addKnob(self.n_name)
		self.addKnob(self.n_save)
		self.addKnob(self.n_delete) 
		self.addKnob(self.n_update)
		self.addKnob(self.n_textCaptured)

		#captured nodes
		initCaptureBtn("nodes", self, capturedNodes, capturedNodesBtn)
		
	def showModalDialog( self ):
		result = nukescripts.PythonPanel.show(self)

	def knobChanged( self, knob ): 

		#flush nodes lists
		global capturedNodesBtn
		global capturedNodes

		if knob.name() == "save nodes":

			sel = nuke.selectedNodes()
			if len(sel)>0:
				
				saveNodes(self.n_name.value(), self)

				name=self.n_name.value()
				if("." in name):
					name = name.split(".")[0]

				i=len(capturedNodesBtn)

				self.capBtn = nuke.PyScript_Knob(name, name)

				if i%5==0:
					self.capBtn.setFlag(nuke.STARTLINE)

				self.addKnob(self.capBtn)
				capturedNodesBtn.append(self.capBtn)
				capturedNodes.append("%s.nk" % self.n_name.value())
	
			elif len(sel)==0:
				nuke.message("Please select at least one node to capture")
	

		if knob.name() == "delete nodes":
			deleteNodesCap(self)			

		if knob.name() == "update nodes":
			
			for capBtn in capturedNodesBtn:
				self.removeKnob(capBtn)

			capturedNodesBtn = []
			capturedNodes = []

			#init all saved nodes
			for capN in os.listdir(captureNodesDir):
				if capN not in dontInclude:
					capturedNodes.append(capN)

			initCaptureBtn("nodes", self, capturedNodes, capturedNodesBtn)

		#capture
		else:
			k = "%s.nk" % knob.name()
			for capN in capturedNodes:
				if k == capN:
					nuke.nodePaste("{0}/{1}.nk".format(captureNodesDir,knob.name()))

def showHelp():
    '''
    goto web
    '''
    url = 'http://www.leafpictures.de/capture'
    webbrowser.open_new(url)

def show(which):
	'''
	show panel
	'''
	if which=="captureImages":
		captureImagesPanel().show()
	elif which=="captureNodes":
		captureNodePanel().show()
		

def collectPanel():
    colPanel = nuke.Panel("Collect Files 1.2 by Mariano Antico")
    colPanel.addFilenameSearch("Output Path:", "")
    colPanel.addButton("Cancel")
    colPanel.addButton("OK")

    retVar = colPanel.show()
    pathVar = colPanel.value("Output Path:")

    return (retVar, pathVar)
	
##################################################

def process_xml():

	# Build the Nuke Panel where locations and stuff is specified.
	p = nuke.Panel("FCP XML Import")
	xml_file = 'FCP XML To Import'
	output_dir = 'Directory to Output Nuke Scripts'
	subdirectories = 'Create subdirectories for each script?'
	render_dir = 'Render Directory for All Write Nodes'
	handle_length = "0 5 10 15 20 30 35 40"
	clip_name_format = "Bypass RED Alexa"
	render_format = 'Prores4444 exr jpg dpx'

	p.addFilenameSearch("FCP XML File", xml_file)
	p.addBooleanCheckBox("Create subdirectories for each script", subdirectories)
	p.addFilenameSearch("Output Directory", output_dir)
	p.addFilenameSearch("Render Directory", render_dir)
	p.addEnumerationPulldown("Handle Length", handle_length)
	p.addEnumerationPulldown("Clip Name Format", clip_name_format)
	p.addEnumerationPulldown("Render Format", render_format)
	p.setWidth(600)
	if not p.show():
		return

	# Assign vars from Nuke Panel user-entered data 
	xml_file 	= p.value("FCP XML File")
	output_dir	= p.value("Output Directory")
	subdirectories = p.value("Create subdirectories for each script")
	render_dir 	= p.value("Render Directory")
	handle_length = int( p.value("Handle Length") )
	clip_name_format = p.value("Clip Name Format")
	render_format = p.value('Render Format')
#######################################################
def collectPanel():
    colPanel = nuke.Panel("Collect Files 1.2 by Mariano Antico")
    colPanel.addFilenameSearch("Output Path:", "")
    colPanel.addButton("Cancel")
    colPanel.addButton("OK")

    retVar = colPanel.show()
    pathVar = colPanel.value("Output Path:")

    return (retVar, pathVar)
####################################################
	p = nuke.Panel("Make Write of Read")

	p.addSingleLineInput(addPathHandle, addPath )
	p.addSingleLineInput(addPrefixHandle, addPrefix )
	p.addSingleLineInput(addPostfixHandle, addPostfix )
	p.addEnumerationPulldown(formatPulldownHandle, formatPulldown )
	p.addEnumerationPulldown(jpegQualityPulldownHandle, jpegQualityPulldown )
	p.addEnumerationPulldown(tiffDatatypePulldownHandle, tiffDatatypePulldown )
	p.addEnumerationPulldown(tiffCompressionPulldownHandle, tiffCompressionPulldown )
	p.addEnumerationPulldown(exrDatatypePulldownHandle, exrDatatypePulldown )
	p.addEnumerationPulldown(exrCompressionPulldownHandle, exrCompressionPulldown )

	p.addButton("Cancel")
	p.addButton("OK")
	result = p.show()
####################################################
def _collectPanel():
	aPanel = nuke.Panel("Collect This Comp")
	aPanel.addFilenameSearch("Output Path:", "...")
	aPanel.addButton("Cancel")
	aPanel.addButton("OK")

	retVar = aPanel.show()
	pathVar = aPanel.value("Output Path:")

	return (retVar, pathVar)
#################################################

p = nuke.Panel('Where do you whant to save?')
    p.setWidth(500)
    p.addBooleanCheckBox('Create a new Project (uncheck ONLY if you already used this script once and you want to import new files)', True)
    p.addFilenameSearch('Folder Path', 'select a folder where you want to save the Project')
    p.addSingleLineInput('Project Name', 'Project Name')
    if p.show() == 1 :
        print (p.value('Create a new Project (uncheck ONLY if you already used this script once and you want to import the new files)') )
        if p.value('Create a new Project (uncheck ONLY if you already used this script once and you want to import new files)') == True :
            savePath = p.value('Folder Path')
            projectName = p.value('Project Name')
            projectPath= '%s/%s ' % (savePath, projectName)
            try :
                os.makedirs(projectPath)
            except OSError :
                nuke.message('the folder %s already exist' % projectName)
                return
#################################################
def createPanel():
	'''
	aligner panel for user
	'''

	p=nuke.Panel('align')
	p.setWidth(400)
	p.addEnumerationPulldown('direction', 'horizontal vertical')
	p.addSingleLineInput('offset', offset)
	return p


def aligner():
	'''
	main
	create panel and call align function
	'''
	sel = nuke.selectedNodes()

	if len(sel) > 1:
		p = createPanel()
		if p.show():
			which = p.value("direction")
			offset = p.value("offset")
			align(sel, which, offset)
	else:
		nuke.message("Please select more than one node.")

############################################
def autocroptool():
	selectedNodes = nuke.selectedNodes()
	for eachNode in selectedNodes:
		# if it's a read node proceed, if not move on to the next selected node
		if eachNode.Class() == "Read":
			# create curveTool node
			curveNode = nuke.nodes.CurveTool()
			# set input 0 to eachNode (a Read node in this case)
			curveNode.setInput(0, eachNode)
			# set the operation to Auto Crop
			curveNode.knob("operation").setValue("Auto Crop")
			# set the ROI to the width and height coming from the Read node
			curveNode["ROI"].setValue([0, 0, eachNode.width(), eachNode.height()])
			# execute Go! button using the project's frame range
			nuke.execute(curveNode, nuke.root().firstFrame(), nuke.root().lastFrame())   #<-- takes project's frame range
			#nuke.execute(curveNode, eachNode.knob("first").value(), eachNode.knob("last").value())    #<-- inherits the range from the read node
			# create crop node
			cropNode = nuke.nodes.Crop()
			# set input 0 to curveNode
			cropNode.setInput(0, curveNode)
			# copy animation from curveTool node
			cropNode.knob("box").copyAnimations(curveNode.knob("autocropdata").animations())
			# set blackoutside to False, otherwise objects can come out with an ugly black outline
			cropNode.knob("crop").setValue(False)

##################################################

######################################

def callInputs():
    selNodes = nuke.selectedNodes()

    clearSelection()

    bd = 0
    sa = nuke.allNodes()
    for nd in sa:
        if nd['name'].value().find('Selection Set') != -1:
            bd += 1

    clearSelection()

    if selNodes:

        bckdrp = nukescripts.autoBackdrop()

        bckdrp['name'].setValue('Selection Set %s' %(bd+1))
        bckdrp['bdwidth'].setValue(120)
        bckdrp['bdheight'].setValue(40)
        bckdrp['tile_color'].setValue(595297535)
        bckdrp['label'].setValue('Add Note')

        p = nuke.toNode('preferences')
        v = p['maxPanels'].value()
        p['maxPanels'].setValue(v+1)

        lon = ''
        miny = -999999999
        minx = 0
        for nd, i in zip(selNodes, range(len(selNodes))):
            if nd['ypos'].value() > miny:
                miny = nd['ypos'].value()
                minx = nd['xpos'].value()
            if i != 0:
                lon += ',%s' %str(nd['name'].value())
            else:
                lon = str(nd['name'].value())

        bckdrp['xpos'].setValue(minx)
        bckdrp['ypos'].setValue(miny + 50)

        t = nuke.Tab_Knob("selectionSet", "Selection Set")
        bckdrp.addKnob(t)

        sel = nuke.PyScript_Knob('selectBtn', '<span>Select Nodes</span>', 'import bi_selectionSet as ss; ss.selectFromSelectionSet("%s")' %(bckdrp['name'].value()))
        dis = nuke.PyScript_Knob('displayBtn', '<span>Display Nodes</span>', 'import bi_selectionSet as ss; ss.displayFromSelectionSet("%s")' %(bckdrp['name'].value()))
        ab = nuke.PyScript_Knob('addBtn', '<span>Add Node(s)</span>', 'import bi_selectionSet as ss; ss.addNodes("%s")' %(bckdrp['name'].value()))
        rb = nuke.PyScript_Knob('refreshBtn', '<span>Refresh</span>', 'import bi_selectionSet as ss; ss.refreshButtons("%s")' %(bckdrp['name'].value()))

        de = nuke.PyScript_Knob('disableEnableToggleBtn', '<span style="color:orange">Disable/Enable Toggle</span>', 'import bi_selectionSet as ss; ss.disEnaToggleFromSelectionSet("%s")' %(bckdrp['name'].value()))
        de.setFlag(nuke.STARTLINE)
        dea = nuke.PyScript_Knob('disableEnableAllBtn', '<span style="color:orange">Disable/Enable All</span>', 'import bi_selectionSet as ss; ss.disEnaAllFromSelectionSet("%s")' %(bckdrp['name'].value()))

        sep = nuke.Text_Knob('separator', 'List of Nodes:', '')

        tm = nuke.Text_Knob('listOfNodes', '', lon)
        tm.setFlag(nuke.INVISIBLE)

        bckdrp.addKnob(sel)
        bckdrp.addKnob(dis)
        bckdrp.addKnob(ab)
        bckdrp.addKnob(rb)
        bckdrp.addKnob(de)
        bckdrp.addKnob(dea)
        bckdrp.addKnob(tm)
        bckdrp.addKnob(sep)

        colorize(bckdrp)

        nuke.show(bckdrp)

    else:
        nuke.executeInMainThread(nuke.message, args=("Select nodes that you want to put into selection set."))

###################################################


